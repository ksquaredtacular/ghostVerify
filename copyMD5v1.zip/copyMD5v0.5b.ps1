# Setup Logging
$logFile = Join-Path $PWD "CopyLog_$(Get-Date -Format 'yyyyMMdd_HHmmss').txt"
function Write-Log($msg, $color = "White", $flag = "INFO") {
    $timestamp = Get-Date -Format "HH:mm:ss"
    $logEntry = "[$timestamp] [$flag] $msg"
    Write-Host $logEntry -ForegroundColor $color
    $logEntry | Out-File -FilePath $logFile -Append
}

# Get subdirectories
$folders = Get-ChildItem -Directory
if ($folders.Count -eq 0) { Write-Log "No subfolders found." "Yellow" "WARN"; exit }

# Display list
Write-Host "Available Subfolders:" -ForegroundColor Cyan
for ($i = 0; $i -lt $folders.Count; $i++) {
    Write-Host ("[{0}] {1}" -f ($i + 1), $folders[$i].Name)
}

# Inputs
$destBase = Read-Host "`nEnter destination path"
$selectionInput = Read-Host "Enter numbers (space separated) or 'all'"
$selection = if ($selectionInput -eq "all") { $folders } else { 
    $indices = $selectionInput.Split(' ', [System.StringSplitOptions]::RemoveEmptyEntries) | ForEach-Object { [int]$_ - 1 }
    $folders[$indices] 
}

Write-Log "Session started. Destination: $destBase" "Cyan" "START"

foreach ($folder in $selection) {
    if (!$folder) { continue }
    $targetPath = Join-Path $destBase $folder.Name
    $checksumFileName = "$($folder.Name).md5"
    $sourceChecksumPath = Join-Path $folder.FullName $checksumFileName
    $isVerifiedOnly = $false

    # 1. Check if folder exists at destination
    if (Test-Path $targetPath) {
        $choice = Read-Host "`nFolder '$($folder.Name)' exists. Verify existing only? (y/n)"
        if ($choice -eq 'y') {
            $isVerifiedOnly = $true
        }
    }

    # 2. Ensure source has an MD5
    if (!(Test-Path $sourceChecksumPath)) {
        Write-Log "Creating source MD5 for $($folder.Name)..." "Gray" "HASH-GEN"
        $fileToHash = Get-ChildItem $folder.FullName -File | Select-Object -First 1
        if ($fileToHash) {
            $hash = (Get-FileHash $fileToHash.FullName -Algorithm MD5).Hash
            "$hash  $($fileToHash.Name)" | Out-File $sourceChecksumPath
        }
    }

    # 3. Copy Logic
    if (-not $isVerifiedOnly) {
        Write-Log "Copying $($folder.Name)..." "White" "COPYING"
        $startTime = Get-Date
        try {
            Copy-Item -Path $folder.FullName -Destination $destBase -Recurse -Force -ErrorAction Stop
            $endTime = Get-Date
            $duration = ($endTime - $startTime).ToString("hh\:mm\:ss")
            Write-Log "Copy complete ($duration)." "Green" "SUCCESS"
        } catch {
            Write-Log "Copy FAILED: $($_.Exception.Message)" "Red" "ERROR"
            continue
        }
    }

    # 4. Verification & Specific Flagging
    $currentFlag = if ($isVerifiedOnly) { "VERIFY-ONLY" } else { "POST-COPY-VERIFY" }
    $destChecksumPath = Join-Path $targetPath $checksumFileName
    
    if (Test-Path $destChecksumPath) {
        $checksumContent = Get-Content $destChecksumPath
        $expectedHash = ($checksumContent -split '\s+')[0]
        $fileToVerifyName = ($checksumContent -split '\s+')[-1]
        $fileToVerifyPath = Join-Path $targetPath $fileToVerifyName
        
        if (Test-Path $fileToVerifyPath) {
            Write-Log "Checking integrity of $fileToVerifyName..." "Yellow" $currentFlag
            $actualHash = (Get-FileHash $fileToVerifyPath -Algorithm MD5).Hash

            if ($actualHash -eq $expectedHash) {
                Write-Log "MATCH: $($folder.Name) is intact." "Green" $currentFlag
            } else {
                Write-Log "MISMATCH: $($folder.Name) is corrupted!" "Red" "CRITICAL"
            }
        } else {
            Write-Log "Target file $fileToVerifyName missing!" "Red" "ERROR"
        }
    }
}

Write-Log "Session Complete. Log: $logFile" "Cyan" "END"
