# Setup Logging
$logFile = Join-Path $PWD "CopyLog_$(Get-Date -Format 'yyyyMMdd_HHmmss').txt"
$sessionStartTime = Get-Date

function Write-Log($msg, $color = "White", $flag = "INFO") {
    $timestamp = Get-Date -Format "HH:mm:ss"
    $logEntry = "[$timestamp] [$flag] $msg"
    Write-Host $logEntry -ForegroundColor $color
    $logEntry | Out-File -FilePath $logFile -Append
}

# Get subdirectories
$folders = Get-ChildItem -Directory
if ($folders.Count -eq 0) { Write-Log "No subfolders found." "Yellow" "WARN"; exit }

# Display list
Write-Host "`nAvailable Subfolders:" -ForegroundColor Cyan
for ($i = 0; $i -lt $folders.Count; $i++) {
    Write-Host ("[{0}] {1}" -f ($i + 1), $folders[$i].Name)
}

# Inputs
$destBase = Read-Host "`nEnter destination path"
if (!(Test-Path $destBase)) { New-Item -ItemType Directory -Path $destBase -Force | Out-Null }

$selectionInput = Read-Host "Enter numbers (space separated) or 'all'"
$selection = if ($selectionInput -eq "all") { $folders } else { 
    $indices = $selectionInput.Split(' ', [System.StringSplitOptions]::RemoveEmptyEntries) | ForEach-Object { [int]$_ - 1 }
    $folders[$indices] 
}

Write-Log "Session started. Destination: $destBase" "Cyan" "START"

foreach ($folder in $selection) {
    if (!$folder) { continue }
    $targetPath = Join-Path $destBase $folder.Name
    $checksumFileName = "$($folder.Name).md5"
    $sourceChecksumPath = Join-Path $folder.FullName $checksumFileName
    $isVerifiedOnly = $false

    # 1. Check if exists at destination
    if (Test-Path $targetPath) {
        $choice = Read-Host "`nFolder '$($folder.Name)' exists. Verify existing only? (y/n)"
        if ($choice -eq 'y') { $isVerifiedOnly = $true }
    }

    # 2. Ensure source has MD5
    if (!(Test-Path $sourceChecksumPath)) {
        Write-Log "Creating source MD5 for $($folder.Name)..." "Gray" "HASH-GEN"
        $fileToHash = Get-ChildItem $folder.FullName -File | Where-Object { $_.Extension -eq ".gho" } | Select-Object -First 1
        if (!$fileToHash) { $fileToHash = Get-ChildItem $folder.FullName -File | Select-Object -First 1 }
        
        if ($fileToHash) {
            $hash = (Get-FileHash $fileToHash.FullName -Algorithm MD5).Hash
            "$hash  $($fileToHash.Name)" | Out-File $sourceChecksumPath
        } else {
            Write-Log "Skipping $($folder.Name): Folder is empty." "Yellow" "SKIP"
            continue
        }
    }

    # 3. Copy Logic
    if (-not $isVerifiedOnly) {
        Write-Log "Copying $($folder.Name)..." "White" "COPYING"
        $copyStart = Get-Date
        try {
            Copy-Item -Path $folder.FullName -Destination $destBase -Recurse -Force -ErrorAction Stop
            $duration = ((Get-Date) - $copyStart).ToString("hh\:mm\:ss")
            Write-Log "Copy complete ($duration)." "Green" "SUCCESS"
        } catch {
            Write-Log "Copy FAILED: $($_.Exception.Message)" "Red" "ERROR"
            continue
        }
    }

    # 4. Final Verification & MD5 Update
    $currentFlag = if ($isVerifiedOnly) { "VERIFY-ONLY" } else { "POST-COPY-VERIFY" }
    $destChecksumPath = Join-Path $targetPath $checksumFileName
    
    if (Test-Path $destChecksumPath) {
        $checksumContent = Get-Content $destChecksumPath | Select-Object -First 1
        if ($checksumContent -match '^([a-fA-F0-9]{32})\s+(.+)$') {
            $expectedHash = $Matches[1]
            $fileToVerifyName = $Matches[2].Trim()
            $fileToVerifyPath = Join-Path $targetPath $fileToVerifyName
            
            # REPAIR: Handle name mismatch
            if (!(Test-Path $fileToVerifyPath)) {
                Write-Log "Name mismatch in MD5. Searching for .gho..." "Yellow" "REPAIR"
                $foundFile = Get-ChildItem $targetPath -Filter "*.gho" | Select-Object -First 1
                if ($foundFile) {
                    $fileToVerifyPath = $foundFile.FullName
                    $fileToVerifyName = $foundFile.Name
                }
            }
            
            if (Test-Path $fileToVerifyPath) {
                Write-Log "Hashing: $fileToVerifyName" "Yellow" $currentFlag
                $actualHash = (Get-FileHash $fileToVerifyPath -Algorithm MD5).Hash

                if ($actualHash -eq $expectedHash) {
                    Write-Log "MATCH: Integrity confirmed." "Green" $currentFlag
                    # Update the MD5 file with the correct name if it was wrong
                    if ($fileToVerifyName -ne $Matches[2].Trim()) {
                        Write-Log "Updating MD5 file with correct filename: $fileToVerifyName" "Gray" "FIXED"
                        "$expectedHash  $fileToVerifyName" | Out-File $destChecksumPath
                        # Also update source if we are in sync
                        if (Test-Path $sourceChecksumPath) { "$expectedHash  $fileToVerifyName" | Out-File $sourceChecksumPath }
                    }
                } else {
                    Write-Log "MISMATCH: $fileToVerifyName is corrupted!" "Red" "CRITICAL"
                }
            } else {
                Write-Log "MISSING FILE: No .gho file found in $targetPath" "Red" "ERROR"
            }
        }
    }
}

$totalElapsed = ((Get-Date) - $sessionStartTime).ToString("hh\:mm\:ss")
Write-Log "-------------------------------------------" "Cyan" "SUMMARY"
Write-Log "Total Elapsed Time: $totalElapsed" "White" "SUMMARY"
Write-Host "`nPress any key to close..." -ForegroundColor Cyan
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
