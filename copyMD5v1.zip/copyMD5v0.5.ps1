# Get all subdirectories
$folders = Get-ChildItem -Directory
if ($folders.Count -eq 0) { Write-Host "No subfolders found." -ForegroundColor Yellow; exit }

# Display the numbered list
Write-Host "Available Subfolders:" -ForegroundColor Cyan
for ($i = 0; $i -lt $folders.Count; $i++) {
    Write-Host ("[{0}] {1}" -f ($i + 1), $folders[$i].Name)
}

# 1. Ask for destination FIRST
$destBase = Read-Host "`nEnter destination path (e.g., D:\Backup)"
if (!(Test-Path $destBase)) { New-Item -ItemType Directory -Path $destBase -Force | Out-Null }

# 2. Get user selection
$selectionInput = Read-Host "Enter numbers to copy (space separated) or 'all'"
$selection = if ($selectionInput -eq "all") { $folders } else { 
    $indices = $selectionInput.Split(' ', [System.StringSplitOptions]::RemoveEmptyEntries) | ForEach-Object { [int]$_ - 1 }
    $folders[$indices] 
}

# 3. Process each folder
foreach ($folder in $selection) {
    if (!$folder) { continue }
    $checksumFile = Join-Path $folder.FullName "$($folder.Name).md5"
    $targetFolder = Join-Path $destBase $folder.Name

    Write-Host "`nProcessing: $($folder.Name)" -ForegroundColor White

    # Check for existing checksum
    if (Test-Path $checksumFile) {
        Write-Host "Found existing checksum. Verifying..." -ForegroundColor Yellow
        $storedHash = (Get-Content $checksumFile).Split(' ')[0]
        # For simplicity, we hash the folder's "contents" as a single stream or check the first file
        # Standard practice: Verify the first file or a master hash file
        $currentHash = (Get-FileHash (Get-ChildItem $folder.FullName -File | Select-Object -First 1).FullName -Algorithm MD5).Hash
        
        if ($currentHash -eq $storedHash) {
            Write-Host "Verification Success!" -ForegroundColor Green
        } else {
            Write-Host "Verification FAILED! Hash mismatch." -ForegroundColor Red
            if ((Read-Host "Continue anyway? (y/n)") -ne 'y') { continue }
        }
    } else {
        # Create new checksum before copying
        Write-Host "No checksum found. Creating one..." -ForegroundColor Gray
        $firstFile = Get-ChildItem $folder.FullName -File | Select-Object -First 1
        if ($firstFile) {
            $newHash = (Get-FileHash $firstFile.FullName -Algorithm MD5).Hash
            "$newHash $($firstFile.Name)" | Out-File $checksumFile
            Write-Host "Created: $($checksumFile)" -ForegroundColor Green
        }
    }

    # Perform Copy
    Write-Host "Copying to $targetFolder..." -ForegroundColor Cyan
    Copy-Item -Path $folder.FullName -Destination $destBase -Recurse -Force
}

Write-Host "`nAll operations complete." -ForegroundColor Green
