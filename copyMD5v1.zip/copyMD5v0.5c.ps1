# Setup Logging
$logFile = Join-Path $PWD "CopyLog_$(Get-Date -Format 'yyyyMMdd_HHmmss').txt"
$sessionStartTime = Get-Date

function Write-Log($msg, $color = "White", $flag = "INFO") {
    $timestamp = Get-Date -Format "HH:mm:ss"
    $logEntry = "[$timestamp] [$flag] $msg"
    Write-Host $logEntry -ForegroundColor $color
    $logEntry | Out-File -FilePath $logFile -Append
}

# Get subdirectories in current location
$folders = Get-ChildItem -Directory
if ($folders.Count -eq 0) { 
    Write-Log "No subfolders found in the current directory." "Yellow" "WARN"
    exit 
}

# Display the numbered list
Write-Host "`nAvailable Subfolders:" -ForegroundColor Cyan
for ($i = 0; $i -lt $folders.Count; $i++) {
    Write-Host ("[{0}] {1}" -f ($i + 1), $folders[$i].Name)
}

# Inputs: Destination and Selection
$destBase = Read-Host "`nEnter destination path (e.g., E:\Backup)"
if (!(Test-Path $destBase)) { 
    New-Item -ItemType Directory -Path $destBase -Force | Out-Null 
}

$selectionInput = Read-Host "Enter numbers to copy (space separated) or 'all'"
$selection = if ($selectionInput -eq "all") { $folders } else { 
    $indices = $selectionInput.Split(' ', [System.StringSplitOptions]::RemoveEmptyEntries) | ForEach-Object { [int]$_ - 1 }
    $folders[$indices] 
}

Write-Log "Session started. Destination: $destBase" "Cyan" "START"

foreach ($folder in $selection) {
    if (!$folder) { continue }
    
    $targetPath = Join-Path $destBase $folder.Name
    $checksumFileName = "$($folder.Name).md5"
    $sourceChecksumPath = Join-Path $folder.FullName $checksumFileName
    $isVerifiedOnly = $false

    # 1. Check if folder exists at destination
    if (Test-Path $targetPath) {
        $choice = Read-Host "`nFolder '$($folder.Name)' exists. Verify existing only? (y/n)"
        if ($choice -eq 'y') {
            $isVerifiedOnly = $true
        }
    }

    # 2. Ensure source has an MD5
    if (!(Test-Path $sourceChecksumPath)) {
        Write-Log "Creating source MD5 for $($folder.Name)..." "Gray" "HASH-GEN"
        $fileToHash = Get-ChildItem $folder.FullName -File | Select-Object -First 1
        if ($fileToHash) {
            $hash = (Get-FileHash $fileToHash.FullName -Algorithm MD5).Hash
            "$hash  $($fileToHash.Name)" | Out-File $sourceChecksumPath
        } else {
            Write-Log "Skipping $($folder.Name): No files found to hash." "Yellow" "SKIP"
            continue
        }
    }

    # 3. Copy Logic
    if (-not $isVerifiedOnly) {
        Write-Log "Copying $($folder.Name)..." "White" "COPYING"
        $copyStartTime = Get-Date
        try {
            Copy-Item -Path $folder.FullName -Destination $destBase -Recurse -Force -ErrorAction Stop
            $copyEndTime = Get-Date
            $duration = ($copyEndTime - $copyStartTime).ToString("hh\:mm\:ss")
            Write-Log "Copy complete. Duration: $duration" "Green" "SUCCESS"
        } catch {
            Write-Log "Copy FAILED for $($folder.Name): $($_.Exception.Message)" "Red" "ERROR"
            continue
        }
    }

    # 4. Final Verification
    $currentFlag = if ($isVerifiedOnly) { "VERIFY-ONLY" } else { "POST-COPY-VERIFY" }
    $destChecksumPath = Join-Path $targetPath $checksumFileName
    
    if (Test-Path $destChecksumPath) {
        $checksumContent = Get-Content $destChecksumPath | Select-Object -First 1
        
        if ($checksumContent -match '^([a-fA-F0-9]{32})\s+(.+)$') {
            $expectedHash = $Matches[1]
            $fileToVerifyName = $Matches[2].Trim()
            $fileToVerifyPath = Join-Path $targetPath $fileToVerifyName
            
            if (Test-Path $fileToVerifyPath) {
                Write-Log "Checking integrity of: $fileToVerifyName" "Yellow" $currentFlag
                $actualHash = (Get-FileHash $fileToVerifyPath -Algorithm MD5).Hash

                if ($actualHash -eq $expectedHash) {
                    Write-Log "MATCH: $($folder.Name) integrity confirmed." "Green" $currentFlag
                } else {
                    Write-Log "MISMATCH: Hash at destination differs for $fileToVerifyName!" "Red" "CRITICAL"
                }
            } else {
                Write-Log "MISSING FILE: Expected '$fileToVerifyName' inside $targetPath" "Red" "ERROR"
                $actualFiles = (Get-ChildItem $targetPath -File).Name -join ", "
                Write-Log "Found files: $actualFiles" "Gray" "DEBUG"
            }
        } else {
            Write-Log "MALFORMED MD5: Content in $checksumFileName format error." "Red" "ERROR"
        }
    } else {
        Write-Log "NO MD5 FOUND: Skipping verification for $($folder.Name)." "Yellow" "WARN"
    }
}

# Calculate Total Session Time
$sessionEndTime = Get-Date
$totalElapsed = ($sessionEndTime - $sessionStartTime).ToString("hh\:mm\:ss")

Write-Log "-------------------------------------------" "Cyan" "SUMMARY"
Write-Log "Session Complete." "Cyan" "END"
Write-Log "Total Elapsed Time: $totalElapsed" "White" "SUMMARY"
Write-Log "Log saved to: $logFile" "Gray" "FILE"

Write-Host "`nPress any key to close..." -ForegroundColor Cyan
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
