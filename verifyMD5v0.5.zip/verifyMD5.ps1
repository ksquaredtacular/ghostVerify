# Parameters
$RootPath = Get-Location
$LogDir   = Join-Path $RootPath "Misc\Logs"
$LogFile  = Join-Path $LogDir "verifyMD5.log"
$CreateMissing = $true

# Ensure Logs directory exists
if (!(Test-Path $LogDir)) { New-Item -ItemType Directory -Path $LogDir | Out-Null }

# Initialize Log
"--- Hash Check Log Started: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') ---" | Out-File $LogFile

# 1. Recursively find target files
$Files = Get-ChildItem -Path $RootPath -Recurse -File -Include *.gho, *.iso, *.img, *.zip

foreach ($File in $Files) {
    $TimeStamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $BaseName  = $File.BaseName
    $MD5Path   = Join-Path $File.DirectoryName "$BaseName.md5"
    
    Write-Host "[$TimeStamp] Processing: $($File.Name)" -ForegroundColor Cyan

    if (Test-Path $MD5Path) {
        # VERIFY
		$ExpectedHash = ((Get-Content $MD5Path -First 1 -ErrorAction SilentlyContinue) -split '\s+')[0]
        $ActualHash   = (Get-FileHash $File.FullName -Algorithm MD5).Hash

        if ($ActualHash -eq $ExpectedHash) {
            $Status = "PASS"
            $Color  = "Green"
        } else {
            $Status = "FAIL (Mismatch)"
            $Color  = "Red"
        }
    } 
    elseif ($CreateMissing) {
        # CREATE
        $ActualHash = (Get-FileHash $File.FullName -Algorithm MD5).Hash
        "$ActualHash  $($File.Name)" | Out-File $MD5Path
        $Status = "CREATED MD5"
        $Color  = "Yellow"
    } else {
        $Status = "SKIPPED (No MD5)"
        $Color  = "Gray"
    }

    # LOG and Output with Timestamp
    $LogEntry = "[$TimeStamp] $Status | $($File.FullName)"
    $LogEntry | Out-File $LogFile -Append
    Write-Host "  -> $Status" -ForegroundColor $Color
}

Write-Host "Check complete. Log: $LogFile" -ForegroundColor Magenta
